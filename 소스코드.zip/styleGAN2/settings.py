
def init():
    global dis_do
    dis_do = False