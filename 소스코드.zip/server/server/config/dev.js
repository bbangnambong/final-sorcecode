module.exports = {
    mongoURI:
        "mongodb+srv://dbUser:9NL2WN10J4HhEEol@homeshopping.a1v28.mongodb.net/homeshopping?retryWrites=true&w=majority",
};
