const clothes = [
    {
        _id: 1,
        name: "상의",
    },
    {
        _id: 2,
        name: "하의",
    },
    {
        _id: 3,
        name: "한벌옷",
    },
    {
        _id: 4,
        name: "신발",
    },
    {
        _id: 5,
        name: "모자",
    },
    {
        _id: 6,
        name: "가방",
    },
    {
        _id: 7,
        name: "악세사리",
    },
];

export { clothes };
